---
title: Hello，Apple TV
date: 2023-10-30T02:54:33
tags:
  - tech
  - hello
draft: false
hideInList: false
feature: 
isTop: false
---
倒卖了闲置的iPhone，因此有额外的零花钱，于是购入了Apple TV 2023款 64GB港版。


渠道：京东。

![image.png](https://bestkxt.oss-cn-guangzhou.aliyuncs.com/img/202310310435591.png)

# 8字电源线
港版的电源线不能直接使用，因此购入了绿联的电源线进行替换，花费12¥。
# infuse pro
> 用途：支持6个设备，在阿里云盘存取资源，infuse即可构建海报墙

流程：
- 申请土区Apple ID，使用大众点评模拟当地地址电话+付款方式为空
- 土区[onyunfor](https://www.oyunfor.com/)礼品卡购买100里拉，花费26¥
- Apple store订阅infuse pro年费
- 片源获取：[云盘4K-综合网盘搜索](https://www.codelicence.cn/)+telegram电报群资源

遇到问题：AppleTV上的infuse Pro中阿里网盘服务器读取不到？
解决方法：使用Mac进行初始化库即可。

![image.png](https://bestkxt.oss-cn-guangzhou.aliyuncs.com/img/202310310441076.png)
![image.png](https://bestkxt.oss-cn-guangzhou.aliyuncs.com/img/202310310440711.png)

# cheers
也就是第三方版的b站，闲鱼购买账号进行下载，花费3.88¥。
# youtube prime
- 油管会员，用于去广告，还附赠了YouTube music，体验很不错。
- 渠道：电报群拼车。
- 花费：年付45¥。
# iplaytv
- 渠道：闲鱼账号附赠，无需花费。
- 进阶：搜索**m3u直播源**，导入配置订阅即可。

# 总结
按我这种最低开销，买完Apple TV也得多花一百块钱来配置软件生态。

<!--more-->