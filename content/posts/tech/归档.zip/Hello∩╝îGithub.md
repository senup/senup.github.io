---
title: Hello，Github
date: 2023-11-09T01:47:03
tags:
  - git
  - tech
  - hello
draft: true
hideInList: false
feature: 
isTop: false
---

# github挂载配置
https://raw.githubusercontent.com/Moli-X/Resources/main/Script/Bilibili/AD_Bilibili.conf
研究QuantumultX的时候，发现这种raw.githubusercontent.com的域名有种似曾相识的感觉，但是没想出来github什么时候提供了这种功能。后面发现自己傻了，这其实就是普通仓库中某个文件的raw格式。
![image.png](https://bestkxt.oss-cn-guangzhou.aliyuncs.com/img/202311120152504.png)



# gist是什么


<!--more-->