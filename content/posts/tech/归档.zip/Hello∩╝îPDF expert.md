---
title: Hello，PDF expert
date: 2023-11-17 13:27:29
tags:
  - tech
  - hello
  - mac
  - pdf
draft: true
hideInList: false
feature: 
isTop: false
---

PDF expert 应该是 Mac 上体验较为友好的阅读器了，启动速度快，没有花里胡哨的广告和收费，用的很舒心。


## 隐藏
隐藏，能够把很多广告推广信息，直接隐藏掉，这点贼厉害👍。

使用方法：点击顶部栏的编辑-点击隐藏，然后右侧边栏就会有个🔍的按钮，点击进行搜索能够列出所有相关的匹配项，然后最下面就会有擦除和擦除全部的按钮，点击即可全部抹除搜索的匹配项。
![image.png](https://bestkxt.oss-cn-guangzhou.aliyuncs.com/img/202311171332356.png)


<!--more-->
## PDF 合并
这个倒是没啥好说的。



