---
title: Hello，VS code
date: 2023-11-13 16:00:07
tags:
  - tech
  - hello
draft: true
hideInList: false
feature: 
isTop: false
---
罗列一些用到的插件。
# project manager
解决了编辑器上面只能支持单项目的问题。安装此插件后侧栏会多出一个**项目管理器**的按钮，此时只需要点击按钮，进入选项卡点下“保存”的图标，那么就能将你的项目进行存储并管理，十分好用👍🏻。

<!--more-->