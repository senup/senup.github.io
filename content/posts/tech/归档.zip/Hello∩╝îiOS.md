---
title: Hello，iOS
date: 2023-11-08 15:54:54
tags:
  - iOS
  - tech
  - hello
draft: true
hideInList: false
feature: 
isTop: false
---


# 去除应用评分弹窗
在**设置**中找到 **App Store**，关闭这个选项
![image.png](https://bestkxt.oss-cn-guangzhou.aliyuncs.com/img/202311081556244.png)


<!--more-->